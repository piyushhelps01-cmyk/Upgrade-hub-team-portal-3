const fs = require('node:fs');
const path = require('node:path');
const { modules, fieldSchemas, roleLabels } = require('../src/modules');

const root = path.resolve(__dirname, '..');
const csvPath = path.join(root, 'docs', 'MASTER_CHECKLIST_732.csv');
const csv = fs.readFileSync(csvPath, 'utf8').replace(/^\uFEFF/, '');
const lines = csv.trim().split(/\r?\n/);
function parseCsvLine(line) {
  const fields = []; let field = ''; let quoted = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"' && quoted && line[i + 1] === '"') { field += '"'; i++; }
    else if (ch === '"') quoted = !quoted;
    else if (ch === ',' && !quoted) { fields.push(field); field = ''; }
    else field += ch;
  }
  fields.push(field);
  return fields;
}
const header = lines[0];
const parsedRows = lines.slice(1).map(parseCsvLine);
const ids = parsedRows.map(row => row[0]);
const sections = new Set(parsedRows.map(row => row[1]));
const requiredFiles = [
  'README.md', '.env.example', 'src/server.js', 'src/db.js', 'src/modules.js',
  'public/index.html', 'public/app.js', 'public/styles.css',
  'docs/ROLE_MATRIX.md', 'docs/IMPLEMENTATION_MATRIX.md', 'docs/RELEASE_READINESS.md',
  'docs/MASTER_CHECKLIST_732.md', 'docs/MASTER_CHECKLIST_732.csv', 'docs/ACCEPTANCE_TEST_REPORT.md', 'public/assets/upgradehub-team-logo.png', 'public/assets/upgradehub-team-emblem.png', 'preview/UpgradeHub_UI_Preview.html'
];
const missing = requiredFiles.filter(file => !fs.existsSync(path.join(root, file)));
const errors = [];
if (modules.length !== 67) errors.push(`Expected 67 modules, got ${modules.length}`);
if (Object.keys(fieldSchemas).length !== modules.length) errors.push('Every module must have a field schema');
if (Object.keys(roleLabels).length !== 7) errors.push(`Expected 7 roles, got ${Object.keys(roleLabels).length}`);
if (lines.length !== 733) errors.push(`Expected 732 checklist rows, got ${lines.length - 1}`);
if (new Set(ids).size !== 732) errors.push('Checklist IDs must be unique');
if (sections.size !== 79 || sections.has('')) errors.push(`Expected 79 parsed checklist sections, got ${sections.size}`);
for (const key of ['Related modules', 'Suggested owner', 'Acceptance check', 'Validation result']) {
  if (!header.includes(key)) errors.push(`Checklist column missing: ${key}`);
}
if (missing.length) errors.push(`Missing required files: ${missing.join(', ')}`);
if (errors.length) {
  console.error('PACKAGE VALIDATION FAILED');
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}
console.log('PACKAGE VALIDATION PASSED');
console.log(JSON.stringify({ modules: modules.length, schemas: Object.keys(fieldSchemas).length, roles: Object.keys(roleLabels).length, checklistControls: ids.length, checklistSections: sections.size, requiredFiles: requiredFiles.length }, null, 2));
