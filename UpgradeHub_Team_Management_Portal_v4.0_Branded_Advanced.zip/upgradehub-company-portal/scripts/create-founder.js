require('dotenv').config();
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const db = require('../src/db');
(async()=>{
  const email=String(process.env.FOUNDER_EMAIL||'').trim().toLowerCase();
  const password=String(process.env.FOUNDER_PASSWORD||'');
  const name=String(process.env.FOUNDER_NAME||'UpgradeHub Founder').trim();
  if(!email||!/^\S+@\S+\.\S+$/.test(email)||password.length<16){
    console.error('Set FOUNDER_EMAIL, FOUNDER_NAME and FOUNDER_PASSWORD (minimum 16 characters) in .env before running npm run setup:founder.');process.exit(1);
  }
  const existing=db.prepare('SELECT id FROM users WHERE email=?').get(email);
  if(existing){console.error('An account with this email already exists. No changes made.');process.exit(1);}
  const id=crypto.randomUUID(),stamp=new Date().toISOString(),hash=await bcrypt.hash(password,12);
  db.prepare(`INSERT INTO users(id,email,password_hash,full_name,employee_id,designation,department,role,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id,email,hash,name,'UH-FOUNDER','Founder','Leadership','founder','active',stamp,stamp);
  console.log(`Founder account created for ${email}. Keep credentials private and enable MFA at the production identity layer.`);
  db.close();
})().catch(e=>{console.error(e.message);process.exit(1);});
