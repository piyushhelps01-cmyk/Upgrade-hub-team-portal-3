require('dotenv').config();
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawnSync } = require('child_process');
const { pipeline } = require('stream/promises');
const { createReadStream, createWriteStream } = require('fs');
const db = require('../src/db');

(async () => {
  const key = Buffer.from(process.env.BACKUP_ENCRYPTION_KEY || '', 'base64');
  if (key.length !== 32) {
    console.error('BACKUP_ENCRYPTION_KEY must be base64 for exactly 32 random bytes. Generate: openssl rand -base64 32');
    process.exit(1);
  }
  const projectRoot = path.resolve('.');
  const dbPath = path.resolve(process.env.DATABASE_PATH || './data/upgradehub.sqlite');
  const uploadDir = path.resolve(process.env.UPLOAD_DIR || './private_uploads');
  const backupDir = path.resolve(process.env.BACKUP_DIR || './backups');
  fs.mkdirSync(backupDir, { recursive: true, mode: 0o700 });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'uh-backup-'));
  const bundle = path.join(work, 'bundle');
  const snapshotDir = path.join(bundle, 'data');
  const snapshotPath = path.join(snapshotDir, 'upgradehub.sqlite');
  const bundleUploads = path.join(bundle, 'private_uploads');
  const archivePath = path.join(work, 'upgradehub-bundle.tar.gz');
  const outPath = path.join(backupDir, `upgradehub-${stamp}.uhbak`);
  try {
    if (!fs.existsSync(dbPath)) throw new Error(`Database was not found at ${dbPath}`);
    fs.mkdirSync(snapshotDir, { recursive: true, mode: 0o700 });
    fs.mkdirSync(bundleUploads, { recursive: true, mode: 0o700 });
    // better-sqlite3's online backup API captures a consistent database snapshot.
    await db.backup(snapshotPath);
    if (fs.existsSync(uploadDir)) {
      const inspectTree = (dir, relative='') => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
          const rel=path.join(relative,entry.name);
          if (entry.isSymbolicLink()) throw new Error(`Refusing to back up symbolic link in private upload directory: ${rel}`);
          if (entry.isDirectory()) inspectTree(path.join(dir,entry.name),rel);
          else if (!entry.isFile()) throw new Error(`Refusing unsupported file-system entry in private upload directory: ${rel}`);
        }
      };
      inspectTree(uploadDir);
      for (const entry of fs.readdirSync(uploadDir, { withFileTypes: true })) {
        const from=path.join(uploadDir,entry.name),to=path.join(bundleUploads,entry.name);
        fs.cpSync(from,to,{recursive:true,errorOnExist:true,force:false,dereference:false});
      }
    }
    const manifest = {
      format: 'UpgradeHubEncryptedBundle', version: 2, createdAt: new Date().toISOString(),
      databaseSnapshot: 'data/upgradehub.sqlite', privateFilesDirectory: 'private_uploads',
      sessionDataIncluded: false,
      sessionNote: 'Session database intentionally excluded; restore should force fresh authentication.',
      sha256: crypto.createHash('sha256').update(fs.readFileSync(snapshotPath)).digest('hex')
    };
    fs.writeFileSync(path.join(bundle, 'manifest.json'), JSON.stringify(manifest, null, 2), { mode: 0o600, flag: 'wx' });
    const tar = spawnSync('tar', ['-czf', archivePath, '-C', work, 'bundle'], { encoding: 'utf8' });
    if (tar.error) throw tar.error;
    if (tar.status !== 0) throw new Error(`Archive creation failed: ${tar.stderr || tar.stdout}`);
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
    // Format UHBK2 | IV(12 bytes) | ciphertext stream | GCM tag(16 bytes).
    fs.writeFileSync(outPath, Buffer.concat([Buffer.from('UHBK2'), iv]), { mode: 0o600, flag: 'wx' });
    await pipeline(createReadStream(archivePath), cipher, createWriteStream(outPath, { flags: 'a', mode: 0o600 }));
    fs.appendFileSync(outPath, cipher.getAuthTag(), { mode: 0o600 });
    console.log(`Encrypted database + private-files backup written: ${outPath}`);
    console.log('Before relying on it, copy to isolated storage and test restoring into an empty test environment.');
  } finally {
    try { db.close(); } catch {}
    fs.rmSync(work, { recursive: true, force: true });
  }
})().catch(error => { console.error(`Backup failed: ${error.message}`); process.exit(1); });
