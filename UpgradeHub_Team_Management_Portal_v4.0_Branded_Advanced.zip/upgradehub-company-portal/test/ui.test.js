'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
const js = fs.readFileSync(path.join(root, 'public', 'app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'public', 'styles.css'), 'utf8');

test('UI IDs are unique and every literal app selector points to an existing element', () => {
  const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]);
  assert.equal(new Set(ids).size, ids.length, 'duplicate HTML id found');
  const idSet = new Set(ids);
  const selectors = [...js.matchAll(/\$\(['"]([^'"]+)['"]\)/g)].map(m => m[1]);
  const missing = [...new Set(selectors.filter(id => !idSet.has(id)))];
  assert.deepEqual(missing, [], `app.js references missing IDs: ${missing.join(', ')}`);
});

test('premium workspace screens and key UI controls exist in the markup', () => {
  for (const id of ['loginView', 'dashboardPage', 'recordsPage', 'membersPage', 'approvalsPage', 'auditPage', 'operationsPage', 'moduleCategoryFilters', 'memberSearch', 'recordSearch', 'taskStatusBars', 'projectSnapshot', 'priorityTasks']) {
    assert.match(html, new RegExp(`\\bid="${id}"`), `missing UI control: ${id}`);
  }
});

test('dashboard visuals are rendered from API data and tasks have a Kanban workflow', () => {
  assert.match(js, /api\('\/api\/dashboard'\)/);
  assert.match(js, /api\(`\/api\/records\/\$\{encodeURIComponent\(key\)\}`\)/);
  assert.match(js, /function renderDashboardWork\(tasks,projects\)/);
  assert.match(js, /function renderTaskKanban\(mod,records,list\)/);
  assert.match(js, /function renderMembersTable\(\)/);
});

test('responsive layout and reduced-motion accessibility styles are present', () => {
  assert.match(css, /@media\s*\(max-width:\s*700px\)/);
  assert.match(css, /@media\s*\(max-width:\s*980px\)/);
  assert.match(css, /prefers-reduced-motion:\s*reduce/);
  assert.match(css, /:focus-visible/);
});
