const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { modules, fieldSchemas, roleLabels } = require('../src/modules');
const root = path.resolve(__dirname, '..');

test('catalogue contains 67 unique dedicated module workspaces', () => {
  assert.equal(modules.length, 67);
  assert.equal(new Set(modules.map(m => m.key)).size, modules.length);
  assert.ok(modules.every(m => m.name && m.category && m.description));
});

test('every module has a non-empty structured field schema', () => {
  assert.equal(Object.keys(fieldSchemas).length, modules.length);
  for (const mod of modules) {
    assert.ok(Array.isArray(fieldSchemas[mod.key]), `${mod.key} has no schema`);
    assert.ok(fieldSchemas[mod.key].length >= 5, `${mod.key} should have useful fields`);
    const keys = fieldSchemas[mod.key].map(f => f[0]);
    assert.equal(new Set(keys).size, keys.length, `${mod.key} contains duplicate field keys`);
    for (const field of fieldSchemas[mod.key]) assert.equal(field.length, 3);
  }
});

test('all seven defined application roles have a label', () => {
  assert.deepEqual(Object.keys(roleLabels).sort(), ['admin','employee','founder','hr','project_lead','security_reviewer','super_admin'].sort());
});

test('member deletion is not exposed and uploads are not a public static directory', () => {
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  assert.doesNotMatch(server, /app\.(delete|del)\(['"]\/api\/members/);
  assert.match(server, /app\.use\(express\.static\(path\.join\(__dirname,'\.\.','public'/);
  assert.doesNotMatch(server, /express\.static\([^\n]*private_uploads/);
  assert.match(server, /bcrypt\.hash\(password,12\)/);
});

test('master checklist contains exactly 732 controls across 79 sections', () => {
  const checklist = fs.readFileSync(path.join(root,'docs','MASTER_CHECKLIST_732.csv'),'utf8');
  const lines = checklist.trim().split(/\r?\n/);
  assert.equal(lines.length, 733);
  assert.match(lines[1], /^"?UH-001/);
  assert.match(lines[732], /^"?UH-732/);
  const markdown = fs.readFileSync(path.join(root,'docs','MASTER_CHECKLIST_732.md'),'utf8');
  assert.match(markdown, /\*\*Sections:\*\*\s*79/);
  const parsed = require('node:fs').readFileSync(path.join(root,'docs','MASTER_CHECKLIST_732.csv'),'utf8').replace(/^\uFEFF/,'');
  const records = parsed.trim().split(/\r?\n/);
  assert.match(records[0], /Related modules.*Suggested owner.*Acceptance check.*Validation result/);
  for (const row of records.slice(1)) assert.match(row, /Not run/);
});


test('employees have a server-side field allowlist for sensitive workflows', () => {
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  assert.match(server, /employeeFieldAllowlist/);
  assert.match(server, /Employees may respond to their existing work-status card/);
  assert.match(server, /result\.approval='submitted'/);
  assert.match(server, /result\.member_id=user\.id/);
});

test('high-risk approval requests require distinct authorised approvers', () => {
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  assert.match(server, /Second approval must come from a different authorised person/);
  assert.match(server, /founderOnlyApprovalTypes/);
  assert.match(server, /The requester cannot approve their own request/);
});

test('encrypted backup operations require Founder/Super Admin and a reason', () => {
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  assert.match(server, /api\/operations\/backups\/run/);
  assert.match(server, /requireRoles\('founder','super_admin'\),async\(req,res\)=>/);
  assert.match(server, /A reason of at least 8 characters is required to create a backup/);
});


test('employee grievance access is limited to a submit-and-review workflow', () => {
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  assert.match(server, /employeeModules = \[.*?'grievances'/s);
  assert.match(server, /employee: \[.*?'grievances'/s);
  assert.match(server, /data\.case_owner=''; data\.conflict_check='pending'/);
  assert.match(server, /grievances.*?restricted/s);
});

test('member project assignments must resolve to a live projects record', () => {
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  assert.match(server, /Assigned project must be an existing, non-archived project record ID/);
  assert.match(server, /SELECT id FROM records WHERE id=\? AND module='projects' AND archived_at IS NULL/);
});

test('health endpoint probes the database instead of claiming an unconditional healthy status', () => {
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  assert.match(server, /db\.prepare\('SELECT 1 AS ok'\)\.get\(\)/);
  assert.match(server, /status:'degraded'.*database:'unavailable'/s);
});


test('project access is scoped to the assigned project and linked task references', () => {
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  assert.match(server, /record\.module==='projects'\) return \!\!user\.assigned_project_id && record\.id===user\.assigned_project_id/);
  assert.match(server, /projectScopedModules\.has\(record\.module\)\) return \!\!user\.assigned_project_id && record\.project_id===user\.assigned_project_id/);
  assert.match(server, /Project Leads cannot create new projects/);
  assert.match(server, /Linked task must exist and be visible to your account/);
});

test('employee helpdesk and grievance submissions can include a request description while identity stays server-controlled', () => {
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  assert.match(server, /helpdesk: \['details','description','category','priority','requester'\]/);
  assert.match(server, /grievances: \['details','description','category','complainant_ref'\]/);
  assert.match(server, /if\(moduleKey==='helpdesk'\) result\.requester=user\.id/);
  assert.match(server, /result\.member_id=user\.id/);
});


test('brand assets are present and the product uses logo-derived blue/white styling', () => {
  assert.ok(fs.existsSync(path.join(root, 'public/assets/upgradehub-team-logo.png')));
  assert.ok(fs.existsSync(path.join(root, 'public/assets/upgradehub-team-emblem.png')));
  const html = fs.readFileSync(path.join(root, 'public/index.html'), 'utf8');
  const css = fs.readFileSync(path.join(root, 'public/styles.css'), 'utf8');
  assert.match(html, /upgradehub-team-logo\.png/);
  assert.match(html, /trackerHubPanel/);
  assert.match(css, /#075fc6/);
  assert.match(css, /tracker-hub-grid/);
});

test('high-risk module permissions are server-gated to Founder and Super Admin', () => {
  const server = fs.readFileSync(path.join(root, 'src/server.js'), 'utf8');
  assert.match(server, /function canReadModule\(user,moduleKey\) \{ if\(founderOnlyModules\.has\(moduleKey\)&&!\['founder','super_admin'\]/);
  assert.match(server, /function canWriteModule\(user,moduleKey\) \{ if\(founderOnlyModules\.has\(moduleKey\)&&!\['founder','super_admin'\]/);
});
