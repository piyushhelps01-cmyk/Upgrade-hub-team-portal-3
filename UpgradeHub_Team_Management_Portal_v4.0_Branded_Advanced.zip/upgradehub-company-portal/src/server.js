require('dotenv').config();
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);
const express = require('express');
const session = require('express-session');
const SQLiteStoreFactory = require('connect-sqlite3');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const db = require('./db');
const { modules, roleLabels, fieldSchemas, restrictedModules, founderOnlyModules } = require('./modules');
const multer = require('multer');

const app = express();
const SQLiteStore = SQLiteStoreFactory(session);
const PORT = Number(process.env.PORT || 3000);
const SESSION_SECRET = process.env.SESSION_SECRET || '';
const APP_ORIGIN = process.env.APP_ORIGIN || `http://localhost:${PORT}`;
const production = process.env.NODE_ENV === 'production';
const now = () => new Date().toISOString();
const id = () => crypto.randomUUID();
const safeUser = (u) => ({ id:u.id, email:u.email, full_name:u.full_name, employee_id:u.employee_id, designation:u.designation, department:u.department, role:u.role, status:u.status, assigned_project_id:u.assigned_project_id, work_contact:u.work_contact, photo_path:u.photo_path, created_at:u.created_at, last_login_at:u.last_login_at });

if (SESSION_SECRET.length < 32) {
  console.error('FATAL: SESSION_SECRET must be set to a random value of at least 32 characters. Copy .env.example to .env and configure it.');
  process.exit(1);
}
fs.mkdirSync(path.resolve('./data'), { recursive:true });
fs.mkdirSync(path.resolve(process.env.UPLOAD_DIR || './private_uploads'), { recursive:true });
const PRIVATE_UPLOAD_DIR=path.resolve(process.env.UPLOAD_DIR || './private_uploads');
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:10*1024*1024,files:1},fileFilter:(req,file,cb)=>{const ext=path.extname(file.originalname||'').toLowerCase();const allowed=new Set(['.pdf','.png','.jpg','.jpeg','.txt','.csv','.docx','.xlsx']);cb(allowed.has(ext)?null:new Error('File type is not allowed.'),allowed.has(ext));}});

app.disable('x-powered-by');
app.set('trust proxy', production ? 1 : false);
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc:["'self'"], scriptSrc:["'self'"], styleSrc:["'self'", "'unsafe-inline'"], imgSrc:["'self'", 'data:'], connectSrc:["'self'"], objectSrc:["'none'"], frameAncestors:["'none'"] } } }));
app.use(express.json({ limit:'1mb' }));
app.use(express.urlencoded({ extended:false, limit:'100kb' }));
app.use(session({
  name:'uh.sid',
  store:new SQLiteStore({ db:'sessions.sqlite', dir:path.resolve('./data'), table:'sessions' }),
  secret:SESSION_SECRET,
  resave:false,
  saveUninitialized:false,
  rolling:true,
  cookie:{ httpOnly:true, sameSite:'strict', secure:production, maxAge:Number(process.env.SESSION_MAX_AGE_HOURS || 8)*60*60*1000 }
}));

// Same-origin protection for browser mutations. API clients must send the configured Origin.
app.use((req,res,next)=>{
  if (!['POST','PUT','PATCH','DELETE'].includes(req.method)) return next();
  const origin = req.get('origin');
  if (origin && origin !== APP_ORIGIN) return res.status(403).json({error:'Origin not allowed'});
  next();
});

function audit(actorId, action, entityType, entityId, outcome='success', reason='', metadata={}) {
  db.prepare(`INSERT INTO audit_logs(id,actor_user_id,action,entity_type,entity_id,outcome,reason,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?)`)
    .run(id(), actorId || null, action, entityType, entityId || null, outcome, reason || null, JSON.stringify(metadata), now());
}
function securityEvent(severity, eventType, actorId, description) {
  const eventId=id();
  db.prepare('INSERT INTO security_events(id,severity,event_type,actor_user_id,description,created_at) VALUES(?,?,?,?,?,?)').run(eventId,severity,eventType,actorId||null,description,now());
  const founders=db.prepare("SELECT id FROM users WHERE role IN ('founder','super_admin') AND status='active'").all();
  const leads=db.prepare("SELECT id FROM users WHERE role='project_lead' AND status='active'").all();
  const recipients=new Set([...founders,...(severity==='critical'?leads:[])].map(x=>x.id));
  const insert=db.prepare('INSERT INTO notifications(id,recipient_user_id,severity,title,message,entity_type,entity_id,created_at) VALUES(?,?,?,?,?,?,?,?)');
  for (const uid of recipients) insert.run(id(),uid,severity,`Security alert: ${eventType}`,description,'security_event',eventId,now());
}
function requireAuth(req,res,next) {
  if (!req.session.userId) return res.status(401).json({error:'Authentication required'});
  const user=db.prepare('SELECT * FROM users WHERE id=?').get(req.session.userId);
  if (!user || user.status!=='active') { req.session.destroy(()=>{}); return res.status(401).json({error:'Account is not active'}); }
  req.user=user; next();
}
function requireRoles(...roles) { return (req,res,next)=>roles.includes(req.user.role)?next():res.status(403).json({error:'Permission denied'}); }
const commonWork = ['projects','milestones','tasks','task_submissions','goals','meetings','knowledge','announcements','decisions','releases','departments','capacity_planning','okr_cycles','customer_feedback','sprint_planning','qa_test_cases','bug_tracker','release_calendar','communication_templates','event_calendar','recognition','service_catalog'];
const hrModules = ['org_directory','onboarding','offboarding','employee_status','attendance','recruitment','training','performance_reviews','kpis','leave','helpdesk','grievances','hr_cases','document_vault','policies','announcements','meetings','assets','inventory','departments','shift_planning','surveys','recognition','event_calendar','digital_id_cards'];
// Admin is an operational role, not a universal viewer of HR/legal/finance records.
const adminModules = ['org_directory','projects','milestones','tasks','task_submissions','goals','knowledge','helpdesk','announcements','meetings','releases','risks','vendors','decisions','inventory','training','departments','capacity_planning','service_catalog','sla_policies','customer_feedback','sprint_planning','qa_test_cases','bug_tracker','release_calendar','api_registry','communication_templates','notification_rules','event_calendar'];
const securityModules = ['incidents','risks','compliance','permissions_access','sessions_devices','integrations','backup_jobs','continuity','data_requests','policies','releases','api_registry','secret_rotation_register','data_retention','legal_holds','report_schedules','qa_test_cases','code_reviews','notification_rules'];
const employeeModules = ['org_directory','projects','tasks','task_submissions','employee_status','attendance','time_tracking','goals','training','knowledge','helpdesk','grievances','announcements','leave','meetings','policies','performance_reviews','data_requests','assets','decisions','departments','okr_cycles','recognition','customer_feedback','event_calendar','digital_id_cards'];
const roleReadMap = {
  founder: modules.map(m=>m.key), super_admin: modules.map(m=>m.key),
  admin: adminModules,
  hr: hrModules,
  project_lead: [...commonWork,'org_directory','employee_status','attendance','time_tracking','kpis','training','assets','helpdesk','leave','risks','policies','performance_reviews','inventory'],
  employee: employeeModules,
  security_reviewer: securityModules
};
const roleWriteMap = {
  founder: modules.map(m=>m.key), super_admin: modules.map(m=>m.key),
  admin: ['projects','milestones','tasks','task_submissions','goals','knowledge','helpdesk','announcements','meetings','releases','risks','vendors','decisions','inventory','departments','capacity_planning','service_catalog','sla_policies','customer_feedback','sprint_planning','qa_test_cases','bug_tracker','release_calendar','api_registry','communication_templates','notification_rules','event_calendar'],
  hr: ['org_directory','onboarding','offboarding','employee_status','attendance','recruitment','training','performance_reviews','kpis','leave','helpdesk','grievances','hr_cases','document_vault','policies','announcements','meetings','assets','inventory','departments','shift_planning','surveys','recognition','event_calendar','digital_id_cards'],
  project_lead: ['projects','milestones','tasks','task_submissions','employee_status','time_tracking','goals','knowledge','helpdesk','announcements','meetings','releases','risks','assets','inventory','performance_reviews','capacity_planning','okr_cycles','customer_feedback','sprint_planning','qa_test_cases','bug_tracker','release_calendar','departments','recognition','event_calendar','service_catalog'],
  employee: ['tasks','task_submissions','employee_status','attendance','time_tracking','helpdesk','grievances','leave','data_requests','performance_reviews','departments','okr_cycles','recognition','customer_feedback','event_calendar','digital_id_cards'],
  security_reviewer: ['incidents','risks','compliance','api_registry','report_schedules','qa_test_cases','code_reviews','notification_rules']
};
function canReadModule(user,moduleKey) { if(founderOnlyModules.has(moduleKey)&&!['founder','super_admin'].includes(user.role))return false; return (roleReadMap[user.role]||[]).includes(moduleKey); }
function canWriteModule(user,moduleKey) { if(founderOnlyModules.has(moduleKey)&&!['founder','super_admin'].includes(user.role))return false; return (roleWriteMap[user.role]||[]).includes(moduleKey); }
function parseRecordData(record) { try { return JSON.parse(record.data_json || '{}'); } catch { return {}; } }
function visibleRecord(user,record) {
  if (user.role==='founder' || user.role==='super_admin') return true;
  const data=parseRecordData(record);
  // Shared company knowledge stays available, while confidentiality labels remain enforced.
  if (['announcements','policies'].includes(record.module)) {
    if (record.sensitivity==='restricted') return ['admin','hr'].includes(user.role);
    return true;
  }
  if (record.module==='knowledge') {
    const classification=data.confidentiality || record.sensitivity || 'internal';
    if (classification==='restricted') return ['admin','hr'].includes(user.role) && (record.owner_user_id===user.id || record.created_by===user.id);
    if (classification==='confidential') return ['admin','hr','project_lead'].includes(user.role) || record.owner_user_id===user.id || record.created_by===user.id;
    return true;
  }
  if (user.role==='admin') return canReadModule(user,record.module) && !['grievances','document_vault','hr_cases','finance','contracts','data_requests','backup_jobs','continuity','permissions_access','sessions_devices'].includes(record.module);
  if (user.role==='hr') {
    if (record.module==='grievances') return !data.case_owner || record.owner_user_id===user.id || record.created_by===user.id || data.case_owner===user.id;
    if (['hr_cases','document_vault'].includes(record.module)) return record.owner_user_id===user.id || record.created_by===user.id || [data.owner,data.case_owner,data.owner_id,data.assignee_id,data.assigned_to].includes(user.id);
    return canReadModule(user,record.module);
  }
  if (user.role==='security_reviewer') return canReadModule(user,record.module) && securityModules.includes(record.module);
  if (user.role==='project_lead') {
    if (record.module==='projects') return !!user.assigned_project_id && record.id===user.assigned_project_id;
    if (projectScopedModules.has(record.module)) return !!user.assigned_project_id && record.project_id===user.assigned_project_id;
    return record.owner_user_id===user.id || record.created_by===user.id || (!!user.assigned_project_id && record.project_id===user.assigned_project_id);
  }
  if (user.role==='employee') {
    if (record.module==='projects') return !!user.assigned_project_id && record.id===user.assigned_project_id;
    if (projectScopedModules.has(record.module) && record.project_id && record.project_id!==user.assigned_project_id) return false;
  }
  const idFields=['member_id','assignee','assigned_to','assignee_id','requester','submitter_id','owner_id','subject_member_id','reviewed_member_id','assigned_to_id'];
  return record.owner_user_id===user.id || record.created_by===user.id || idFields.some(k=>data[k]===user.id || data[k]===user.employee_id);
}
function cleanRecord(r) {
  const data=JSON.parse(r.data_json || '{}');
  if(r.module==='kpis') {
    const target=Number(data.target), actual=Number(data.actual);
    if(Number.isFinite(target)&&Number.isFinite(actual)&&target>0) {
      data.attainment_percent=String(data.direction||'higher')==='lower'?(actual<=target?100:Math.round((target/Math.max(actual,0.000001))*10000)/100):Math.round((actual/target)*10000)/100;
      data.calculation_note='Calculated from the recorded target and actual; review quality/context before making people decisions.';
    }
  }
  return {...r,data,data_json:undefined};
}
const projectScopedModules = new Set(['milestones','tasks','task_submissions','time_tracking','sprint_planning','qa_test_cases','bug_tracker','code_reviews','release_calendar','customer_feedback']);
const employeeFieldAllowlist = {
  tasks: ['details','description','blocker','submission_url','actual_hours'],
  task_submissions: ['task_id','submitter_id','evidence_ref','revision_number'],
  employee_status: ['employee_response','blocker'],
  attendance: ['member_id','work_date','availability','start_time','end_time','note'],
  time_tracking: ['member_id','task_id','work_date','hours','work_summary','billable'],
  helpdesk: ['details','description','category','priority','requester'],
  leave: ['requester','leave_type','start_date','end_date','days'],
  performance_reviews: ['employee_response'],
  data_requests: ['request_type','subject_id','requester','legal_basis'],
  grievances: ['details','description','category','complainant_ref']
};
function shapeRecordData(user,moduleKey,incoming,previous={},mode='patch') {
  const schemas=fieldSchemas[moduleKey]||[];
  const schemaByKey=new Map(schemas.map(f=>[f[0],f]));
  const allowed=new Set(['details','description',...schemaByKey.keys()]);
  const result=mode==='patch'?{...previous}:{};
  for (const [key,raw] of Object.entries(incoming||{})) {
    if (!allowed.has(key)) continue;
    if (user.role==='employee' && !(employeeFieldAllowlist[moduleKey]||[]).includes(key)) continue;
    if (raw===null || raw===undefined) { result[key]=''; continue; }
    const field=schemaByKey.get(key);const type=field?.[2]||'text';
    if (type==='number') {
      if (raw==='') { result[key]=''; continue; }
      const n=Number(raw); if(!Number.isFinite(n)) continue; result[key]=n; continue;
    }
    if (type==='date' || type==='datetime-local') {
      const value=String(raw).slice(0,40); if(value && Number.isNaN(Date.parse(value))) continue; result[key]=value; continue;
    }
    if (type==='url') {
      const value=String(raw).trim().slice(0,2000); if(value && !/^https?:\/\//i.test(value)) continue; result[key]=value; continue;
    }
    if (type.startsWith('select:')) {
      const value=String(raw).slice(0,160);const choices=type.slice(7).split('|');if(value && !choices.includes(value)) continue;result[key]=value;continue;
    }
    result[key]=String(raw).slice(0,10000);
  }
  if(user.role==='employee') {
    if(moduleKey==='leave') result.requester=user.id;
    if(moduleKey==='helpdesk') result.requester=user.id;
    if(moduleKey==='data_requests') { result.requester=user.id; result.subject_id=user.id; if(mode==='create') { result.approval='submitted'; result.reviewer=''; result.completed_at=''; } }
    if(moduleKey==='task_submissions') { result.submitter_id=user.id; result.reviewer_id=''; result.decision='awaiting_review'; result.review_notes=''; }
    if(moduleKey==='attendance' || moduleKey==='time_tracking') { result.approval_status='pending'; result.member_id=user.id; }
  }
  return result;
}
function canWriteExistingRecord(user,moduleKey,record) {
  if(!canWriteModule(user,moduleKey))return false;
  if(user.role==='employee' && moduleKey==='employee_status')return record.owner_user_id===user.id || record.created_by===user.id;
  return true;
}
function addRecordHistory(recordId,moduleKey,actorId,action,beforeValue,afterValue,reason='') {
  db.prepare('INSERT INTO record_history(id,record_id,module,actor_user_id,action,before_json,after_json,reason,created_at) VALUES(?,?,?,?,?,?,?,?,?)')
    .run(id(),recordId,moduleKey,actorId,action,beforeValue===undefined?null:JSON.stringify(beforeValue),afterValue===undefined?null:JSON.stringify(afterValue),reason||null,now());
}
function notifyUser(recipientId,severity,title,message,entityType,entityId) {
  if (!recipientId) return;
  db.prepare('INSERT INTO notifications(id,recipient_user_id,severity,title,message,entity_type,entity_id,created_at) VALUES(?,?,?,?,?,?,?,?)')
    .run(id(),recipientId,severity,title,message,entityType||null,entityId||null,now());
}
function runOperationalReminderJob(actorId='system',runKind='scheduled') {
  const jobId=id(),started=now(),details={overdueTaskNotifications:0,renewalNotifications:0,staleWorkAlerts:0};
  db.prepare('INSERT INTO job_runs(id,job_name,status,details_json,started_at) VALUES(?,?,?,?,?)').run(jobId,'operational_reminders','running','{}',started);
  try {
    const leaders=db.prepare("SELECT id,assigned_project_id FROM users WHERE status='active' AND role IN ('founder','super_admin','project_lead')").all();
    const tasks=db.prepare("SELECT * FROM records WHERE module='tasks' AND archived_at IS NULL AND due_at IS NOT NULL AND due_at<? AND status NOT IN ('done','approved','closed','cancelled')").all(now());
    for(const task of tasks){
      const recipients=new Set(task.owner_user_id?[task.owner_user_id]:[]);
      for(const lead of leaders)if(['founder','super_admin'].includes(db.prepare('SELECT role FROM users WHERE id=?').get(lead.id)?.role)|| (task.project_id&&lead.assigned_project_id===task.project_id))recipients.add(lead.id);
      for(const recipient of recipients){const already=db.prepare("SELECT id FROM notifications WHERE recipient_user_id=? AND entity_id=? AND title='Task overdue reminder' AND created_at>? LIMIT 1").get(recipient,task.id,new Date(Date.now()-24*60*60*1000).toISOString());if(!already){notifyUser(recipient,'warning','Task overdue reminder',task.title,'tasks',task.id);details.overdueTaskNotifications++;}}
    }
    const renewals=db.prepare("SELECT * FROM records WHERE module IN ('contracts','vendors','integrations','assets') AND archived_at IS NULL").all().filter(r=>{try{const d=JSON.parse(r.data_json||'{}');const raw=d.expiry_date||d.renewal_date||d.warranty_until||d.rotation_due;return raw&&Date.parse(raw)>=Date.now()-7*86400000&&Date.parse(raw)<=Date.now()+30*86400000}catch{return false}});
    for(const r of renewals){for(const uid of leaders.filter(x=>['founder','super_admin'].includes(db.prepare('SELECT role FROM users WHERE id=?').get(x.id)?.role)).map(x=>x.id)){const already=db.prepare("SELECT id FROM notifications WHERE recipient_user_id=? AND entity_id=? AND title='Renewal / expiry reminder' AND created_at>? LIMIT 1").get(uid,r.id,new Date(Date.now()-7*86400000).toISOString());if(!already){notifyUser(uid,'warning','Renewal / expiry reminder',r.title,r.module,r.id);details.renewalNotifications++;}}}
    const inactiveDays=Math.max(7,Number(process.env.INACTIVE_AFTER_DAYS||14)),cutoff=new Date(Date.now()-inactiveDays*86400000).toISOString();
    const members=db.prepare("SELECT id,full_name,role,last_login_at,assigned_project_id FROM users WHERE status='active' AND role NOT IN ('founder','super_admin')").all();
    for(const member of members){
      const action=db.prepare('SELECT MAX(created_at) AS last_action FROM audit_logs WHERE actor_user_id=?').get(member.id)?.last_action;
      const work=db.prepare('SELECT MAX(updated_at) AS last_work FROM records WHERE created_by=? OR updated_by=?').get(member.id,member.id)?.last_work;
      const timestamps=[member.last_login_at,action,work].filter(Boolean).sort();const last=timestamps[timestamps.length-1];if(last&&last>=cutoff)continue;
      for(const lead of leaders.filter(x=>['founder','super_admin'].includes(db.prepare('SELECT role FROM users WHERE id=?').get(x.id)?.role)||(member.assigned_project_id&&x.assigned_project_id===member.assigned_project_id))){const already=db.prepare("SELECT id FROM notifications WHERE recipient_user_id=? AND entity_id=? AND title='Work activity needs review' AND created_at>? LIMIT 1").get(lead.id,member.id,new Date(Date.now()-7*86400000).toISOString());if(!already){notifyUser(lead.id,'warning','Work activity needs review',`${member.full_name} has no recorded portal activity for ${inactiveDays}+ days. Verify leave, workload and context before classifying status.`, 'member',member.id);details.staleWorkAlerts++;}}
    }
    db.prepare('UPDATE job_runs SET status=?,details_json=?,finished_at=? WHERE id=?').run('completed',JSON.stringify({...details,runKind}),now(),jobId);
    if(actorId!=='system')audit(actorId,'operational_jobs_run','system',jobId,'success',`Run kind: ${runKind}`,details);
    return {ok:true,jobId,details,runKind};
  } catch(error) {
    db.prepare('UPDATE job_runs SET status=?,details_json=?,finished_at=? WHERE id=?').run('failed',JSON.stringify({error:error.message,details}),now(),jobId);
    securityEvent('warning','operational_job_failed',actorId,`Operational reminder job failed: ${error.message.slice(0,240)}`);throw error;
  }
}
const allowedRecordStatuses = new Set(['open','draft','submitted','in_progress','blocked','awaiting_review','at_risk','overdue','approved','revision_requested','rejected','done','resolved','closed','cancelled','scheduled','published','pending','in_review','accepted','active','inactive','suspended','exited','not_started','complete','completed','paid','archived']);
const highRiskModules = new Set(['contracts','finance','document_vault','grievances','permissions_access','backup_jobs','continuity','data_requests','sessions_devices','purchase_orders','expense_claims','budget_planning','client_accounts','secret_rotation_register','data_retention','legal_holds','report_schedules','digital_id_cards']);
function transitionAllowed(user,moduleKey,oldRecord,newStatus) {
  if(oldRecord.status===newStatus || ['founder','super_admin'].includes(user.role))return true;
  const privileged=['founder','super_admin','admin'];
  if(moduleKey==='leave'){
    if(['admin','hr'].includes(user.role))return ['pending','submitted','approved','rejected','cancelled','closed'].includes(newStatus);
    return ['pending','submitted','cancelled','open'].includes(newStatus) && (oldRecord.owner_user_id===user.id || oldRecord.created_by===user.id);
  }
  if(moduleKey==='task_submissions'){
    if(['admin','project_lead','hr'].includes(user.role))return ['submitted','awaiting_review','accepted','revision_requested','rejected','closed'].includes(newStatus);
    return ['submitted','awaiting_review','in_progress','open'].includes(newStatus) && (oldRecord.owner_user_id===user.id || oldRecord.created_by===user.id);
  }
  if(moduleKey==='employee_status' && !privileged.includes(user.role)&&user.role!=='hr')return false;
  if(moduleKey==='performance_reviews'){
    if(['hr','project_lead','admin'].includes(user.role))return ['draft','submitted','acknowledged','appealed','closed'].includes(newStatus);
    return ['draft','acknowledged','appealed'].includes(newStatus) && (oldRecord.owner_user_id===user.id || oldRecord.created_by===user.id);
  }
  if(user.role==='employee'){
    if(['approved','accepted','resolved','closed','paid','published','complete','completed','archived'].includes(newStatus))return false;
    return ['open','draft','submitted','in_progress','blocked','awaiting_review','cancelled','pending','not_started'].includes(newStatus);
  }
  return true;
}
const loginLimiter=rateLimit({windowMs:Number(process.env.LOGIN_MAX_ATTEMPTS_WINDOW_MINUTES||15)*60*1000,max:Number(process.env.LOGIN_MAX_ATTEMPTS||8),standardHeaders:true,legacyHeaders:false,message:{error:'Too many login attempts. Try again later.'}});

app.get('/api/health', (req,res)=>{ try { db.prepare('SELECT 1 AS ok').get(); return res.json({status:'ok',service:'UpgradeHub Company Portal',timestamp:now(),database:'connected'}); } catch { return res.status(503).json({status:'degraded',service:'UpgradeHub Company Portal',timestamp:now(),database:'unavailable'}); } });
app.get('/api/config',requireAuth,(req,res)=>{const visible=modules.filter(m=>canReadModule(req.user,m.key));res.json({appName:'UpgradeHub Team Portal',version:'4.0.0',modules:visible.map(({key,name,category,description})=>({key,name,category,description})),fieldSchemas:Object.fromEntries(visible.map(m=>[m.key,fieldSchemas[m.key]]))});});
app.post('/api/auth/login',loginLimiter,async(req,res)=>{
  const email=String(req.body.email||'').trim().toLowerCase(); const password=String(req.body.password||'');
  if(!email||!password) return res.status(400).json({error:'Email and password are required'});
  const user=db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if(!user || !(await bcrypt.compare(password,user.password_hash))) { audit(user?.id||null,'login_failed','user',user?.id||null,'denied','Invalid credentials',{email_domain:email.split('@')[1]||''}); return res.status(401).json({error:'Invalid email or password'}); }
  if(user.status!=='active') { audit(user.id,'login_blocked','user',user.id,'denied','Account not active'); return res.status(403).json({error:'Account is not active. Contact an authorised administrator.'}); }
  req.session.regenerate(err=>{
    if(err) return res.status(500).json({error:'Unable to create secure session'});
    req.session.userId=user.id;
    db.prepare('UPDATE users SET last_login_at=?,updated_at=? WHERE id=?').run(now(),now(),user.id);
    audit(user.id,'login_success','user',user.id,'success');
    req.session.save(err2=>err2?res.status(500).json({error:'Unable to save session'}):res.json({user:safeUser({...user,last_login_at:now()})}));
  });
});
app.post('/api/auth/logout',requireAuth,(req,res)=>{ audit(req.user.id,'logout','user',req.user.id); req.session.destroy(()=>{res.clearCookie('uh.sid',{httpOnly:true,sameSite:'strict',secure:production});res.json({ok:true});}); });
app.get('/api/auth/me',requireAuth,(req,res)=>res.json({user:safeUser(req.user)}));
app.post('/api/auth/change-password',requireAuth,async(req,res)=>{
  const current=String(req.body.currentPassword||''); const next=String(req.body.newPassword||'');
  if(next.length<16) return res.status(400).json({error:'New password must be at least 16 characters.'});
  if(!(await bcrypt.compare(current,req.user.password_hash))) return res.status(400).json({error:'Current password is incorrect'});
  const hash=await bcrypt.hash(next,12); db.prepare('UPDATE users SET password_hash=?,updated_at=? WHERE id=?').run(hash,now(),req.user.id);
  audit(req.user.id,'password_changed','user',req.user.id); securityEvent('info','password_changed',req.user.id,`Password changed for ${req.user.email}`);
  req.session.regenerate(err=>{ if(err)return res.status(500).json({error:'Password updated; please sign in again.'}); req.session.userId=req.user.id; req.session.save(()=>res.json({ok:true})); });
});

app.get('/api/dashboard',requireAuth,(req,res)=>{
  const user=req.user;
  const activeMembers=db.prepare("SELECT COUNT(*) AS n FROM users WHERE status='active'").get().n;
  const taskRows=db.prepare("SELECT * FROM records WHERE module='tasks' AND archived_at IS NULL").all().filter(r=>canReadModule(user,'tasks')&&visibleRecord(user,r));
  const openTasks=taskRows.filter(r=>!['done','approved','closed','cancelled'].includes(r.status)).length;
  const overdue=taskRows.filter(r=>r.due_at&&r.due_at<now()&&!['done','approved','closed','cancelled'].includes(r.status)).length;
  const ticketRows=canReadModule(user,'helpdesk')?db.prepare("SELECT * FROM records WHERE module='helpdesk' AND archived_at IS NULL").all().filter(r=>visibleRecord(user,r)):[];
  const openTickets=ticketRows.filter(r=>!['resolved','closed'].includes(r.status)).length;
  const unread=db.prepare('SELECT COUNT(*) AS n FROM notifications WHERE recipient_user_id=? AND read_at IS NULL').get(user.id).n;
  const recent=db.prepare('SELECT id,action,entity_type,entity_id,outcome,created_at FROM audit_logs WHERE actor_user_id=? ORDER BY created_at DESC LIMIT 8').all(user.id);
  const cards={activeMembers,openTasks,overdue,openTickets,unread};
  if(!['founder','super_admin','admin'].includes(user.role)) delete cards.activeMembers;
  res.json({cards,recentActivity:recent,role:user.role});
});
app.get('/api/modules',requireAuth,(req,res)=>res.json({modules:modules.filter(m=>canReadModule(req.user,m.key)).map(m=>({...m,canWrite:canWriteModule(req.user,m.key)}))}));
app.get('/api/records/:module',requireAuth,(req,res)=>{
  const mod=modules.find(m=>m.key===req.params.module); if(!mod)return res.status(404).json({error:'Unknown module'});
  if(!canReadModule(req.user,mod.key))return res.status(403).json({error:'Permission denied'});
  const rows=db.prepare('SELECT * FROM records WHERE module=? AND archived_at IS NULL ORDER BY updated_at DESC LIMIT 500').all(mod.key).filter(r=>visibleRecord(req.user,r));
  audit(req.user.id,'records_listed',mod.key,null,'success','',{count:rows.length});
  res.json({records:rows.map(cleanRecord)});
});
app.post('/api/records/:module',requireAuth,(req,res)=>{
  const mod=modules.find(m=>m.key===req.params.module); if(!mod)return res.status(404).json({error:'Unknown module'});
  if(!canWriteModule(req.user,mod.key))return res.status(403).json({error:'Permission denied'});
  if(req.user.role==='employee' && mod.key==='employee_status')return res.status(403).json({error:'Employees may respond to their existing work-status card but cannot create or classify one.'});
  if(req.user.role==='security_reviewer' && !['incidents','risks','compliance'].includes(mod.key))return res.status(403).json({error:'Security Reviewer may create incident/risk/compliance records only.'});
  const body=req.body||{}; const title=String(body.title||'').trim();
  if(!title || title.length>180)return res.status(400).json({error:'Title is required and must be under 180 characters.'});
  const incoming=body.data&&typeof body.data==='object'&&!Array.isArray(body.data)?body.data:{};
  let projectId=body.project_id||null;
  if(mod.key==='milestones' && incoming.project_id!==undefined)projectId=String(incoming.project_id||'')||null;
  if(req.user.role==='project_lead' && mod.key==='projects')return res.status(403).json({error:'Project Leads cannot create new projects. An authorised administrator must create and assign projects.'});
  if(projectId && mod.key!=='projects' && !db.prepare("SELECT id FROM records WHERE id=? AND module='projects' AND archived_at IS NULL").get(String(projectId)))return res.status(400).json({error:'Linked project must be an existing, non-archived project record.'});
  if(req.user.role==='project_lead' && projectScopedModules.has(mod.key) && (!req.user.assigned_project_id || projectId!==req.user.assigned_project_id))return res.status(403).json({error:'Project Leads can only create project-scoped work inside their assigned project.'});
  if(req.user.role==='project_lead' && projectId && projectId!==req.user.assigned_project_id)return res.status(403).json({error:'Project Lead can only write to their assigned project.'});
  if(req.user.role==='employee' && projectId) {
    const project=db.prepare("SELECT * FROM records WHERE id=? AND module='projects' AND archived_at IS NULL").get(projectId);
    if(!project || !visibleRecord(req.user,project) || (req.user.assigned_project_id && projectId!==req.user.assigned_project_id))return res.status(403).json({error:'You can only link work to your assigned/authorised project.'});
  }
  const ownerId=req.user.role==='employee'?req.user.id:(body.owner_user_id||req.user.id);
  const owner=db.prepare('SELECT id,status FROM users WHERE id=?').get(ownerId);
  if(!owner || owner.status==='exited')return res.status(400).json({error:'Owner must be an existing non-exited member.'});
  if(!['founder','super_admin','admin','hr'].includes(req.user.role) && ownerId!==req.user.id && !(req.user.role==='project_lead' && projectId===req.user.assigned_project_id))return res.status(403).json({error:'You cannot assign this record to another member.'});
  const sensitivity=mod.key==='grievances'?'restricted':(['public','internal','confidential','restricted'].includes(body.sensitivity)?body.sensitivity:'internal');
  const data=shapeRecordData(req.user,mod.key,incoming,{},'create');
  if(mod.key==='milestones' && projectId)data.project_id=String(projectId);
  if(['task_submissions','time_tracking'].includes(mod.key) && data.task_id) {
    const task=db.prepare("SELECT * FROM records WHERE id=? AND module='tasks' AND archived_at IS NULL").get(String(data.task_id));
    if(!task || !visibleRecord(req.user,task))return res.status(400).json({error:'Linked task must exist and be visible to your account.'});
    if(projectId && task.project_id && projectId!==task.project_id)return res.status(400).json({error:'The selected task belongs to a different project.'});
    projectId=task.project_id||projectId||null;
  }
  if(mod.key==='task_submissions' && !data.task_id)return res.status(400).json({error:'A task submission must reference an existing visible task.'});
  if(req.user.role==='project_lead' && projectScopedModules.has(mod.key) && projectId!==req.user.assigned_project_id)return res.status(403).json({error:'The linked task/project is outside your assigned project.'});
  if(req.user.role==='employee' && mod.key==='grievances') { data.complainant_ref=req.user.id; data.case_owner=''; data.conflict_check='pending'; }
  const defaultStatusByModule={task_submissions:'submitted',grievances:'submitted',data_requests:'submitted',leave:'pending',attendance:'pending',time_tracking:'pending',contracts:'draft',announcements:'draft',policies:'draft',kpis:'draft',performance_reviews:'draft',onboarding:'not_started',offboarding:'in_progress',releases:'draft',training:'not_started'};
  const status=String(body.status||defaultStatusByModule[mod.key]||(mod.key==='grievances'?'submitted':'open')); if(!allowedRecordStatuses.has(status))return res.status(400).json({error:'Invalid status value.'});
  if(req.user.role==='employee'&&['approved','accepted','resolved','closed','paid','published','complete','completed','archived'].includes(status))return res.status(403).json({error:'Employee accounts cannot create records in an approved/final state.'});
  if(highRiskModules.has(mod.key)&&!String(body.reason||'').trim())return res.status(400).json({error:'A clear reason is required to create a sensitive record.'});
  const dueAt=body.due_at||null;
  if(dueAt && Number.isNaN(Date.parse(dueAt)))return res.status(400).json({error:'Invalid due date.'});
  const recordId=id(),stamp=now();
  try {
    db.prepare(`INSERT INTO records(id,module,title,status,owner_user_id,project_id,due_at,sensitivity,data_json,created_by,updated_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(recordId,mod.key,title,status,ownerId,projectId,dueAt,sensitivity,JSON.stringify(data),req.user.id,req.user.id,stamp,stamp);
  } catch(err) { if(String(err.message).includes('FOREIGN KEY'))return res.status(400).json({error:'Owner or creator reference is invalid.'}); throw err; }
  const record=db.prepare('SELECT * FROM records WHERE id=?').get(recordId);
  audit(req.user.id,'record_created',mod.key,recordId,'success','',{sensitivity,status,ownerId,projectId});
  addRecordHistory(recordId,mod.key,req.user.id,'created',null,{title,status,owner_user_id:ownerId,project_id:projectId,due_at:dueAt,sensitivity,data});
  if(ownerId!==req.user.id)notifyUser(ownerId,'info','New item assigned',title,mod.key,recordId);
  if(['tasks','incidents','helpdesk','grievances','risks'].includes(mod.key)) notifyLeadsAndFounder(req.user,mod.key,recordId,title);
  res.status(201).json({record:cleanRecord(record)});
});
app.patch('/api/records/:module/:id',requireAuth,(req,res)=>{
  const mod=modules.find(m=>m.key===req.params.module); if(!mod)return res.status(404).json({error:'Unknown module'});
  const old=db.prepare('SELECT * FROM records WHERE id=? AND module=? AND archived_at IS NULL').get(req.params.id,mod.key);
  if(!old)return res.status(404).json({error:'Record not found'});
  if(!canWriteExistingRecord(req.user,mod.key,old))return res.status(403).json({error:'Permission denied'});
  if(!visibleRecord(req.user,old))return res.status(403).json({error:'Permission denied'});
  if(req.user.role==='security_reviewer' && !['incidents','risks','compliance'].includes(mod.key))return res.status(403).json({error:'Security Reviewer may update incident/risk/compliance records only.'});
  const b=req.body||{}; const title=b.title===undefined?old.title:String(b.title).trim();
  if(!title || title.length>180)return res.status(400).json({error:'Title is required and must be under 180 characters.'});
  const status=b.status===undefined?old.status:String(b.status);
  if(!allowedRecordStatuses.has(status))return res.status(400).json({error:'Invalid status value.'});
  if(!transitionAllowed(req.user,mod.key,old,status))return res.status(403).json({error:'This role cannot perform that status transition. Use the appropriate review/approval workflow.'});
  const due=b.due_at===undefined?old.due_at:(b.due_at||null);
  if(due && Number.isNaN(Date.parse(due)))return res.status(400).json({error:'Invalid due date.'});
  const oldData=parseRecordData(old);
  const incoming=b.data===undefined?{}:(b.data&&typeof b.data==='object'&&!Array.isArray(b.data)?b.data:{});
  let projectId=b.project_id===undefined?old.project_id:(b.project_id||null);
  if(mod.key==='milestones' && incoming.project_id!==undefined)projectId=String(incoming.project_id||'')||null;
  if(projectId && mod.key!=='projects' && !db.prepare("SELECT id FROM records WHERE id=? AND module='projects' AND archived_at IS NULL").get(String(projectId)))return res.status(400).json({error:'Linked project must be an existing, non-archived project record.'});
  if(req.user.role==='project_lead' && projectScopedModules.has(mod.key) && (!req.user.assigned_project_id || projectId!==req.user.assigned_project_id))return res.status(403).json({error:'Project Leads can only update project-scoped work inside their assigned project.'});
  if(req.user.role==='project_lead' && projectId && projectId!==req.user.assigned_project_id)return res.status(403).json({error:'Project Lead can only use their assigned project.'});
  if(req.user.role==='employee' && projectId && projectId!==old.project_id) {
    const project=db.prepare("SELECT * FROM records WHERE id=? AND module='projects' AND archived_at IS NULL").get(projectId);
    if(!project || !visibleRecord(req.user,project) || (req.user.assigned_project_id && projectId!==req.user.assigned_project_id))return res.status(403).json({error:'You can only link work to your assigned/authorised project.'});
  }
  const ownerId=b.owner_user_id===undefined?old.owner_user_id:(b.owner_user_id||req.user.id);
  if(ownerId!==old.owner_user_id && !['founder','super_admin','admin','hr'].includes(req.user.role) && !(req.user.role==='project_lead' && projectId===req.user.assigned_project_id))return res.status(403).json({error:'Reassignment permission denied.'});
  if(ownerId && !db.prepare('SELECT id FROM users WHERE id=? AND status!=\'exited\'').get(ownerId))return res.status(400).json({error:'Owner must be an existing non-exited member.'});
  const data=shapeRecordData(req.user,mod.key,incoming,oldData,'patch');
  if(mod.key==='milestones' && projectId)data.project_id=String(projectId);
  if(['task_submissions','time_tracking'].includes(mod.key) && data.task_id) {
    const task=db.prepare("SELECT * FROM records WHERE id=? AND module='tasks' AND archived_at IS NULL").get(String(data.task_id));
    if(!task || !visibleRecord(req.user,task))return res.status(400).json({error:'Linked task must exist and be visible to your account.'});
    if(projectId && task.project_id && projectId!==task.project_id)return res.status(400).json({error:'The selected task belongs to a different project.'});
    projectId=task.project_id||projectId||null;
  }
  if(mod.key==='task_submissions' && !data.task_id)return res.status(400).json({error:'A task submission must reference an existing visible task.'});
  if(req.user.role==='project_lead' && projectScopedModules.has(mod.key) && projectId!==req.user.assigned_project_id)return res.status(403).json({error:'The linked task/project is outside your assigned project.'});
  if(req.user.role==='employee' && (mod.key==='attendance'||mod.key==='time_tracking'))data.member_id=req.user.id;
  const reason=String(b.reason||'').trim().slice(0,500);
  if((['restricted','confidential'].includes(old.sensitivity) || highRiskModules.has(mod.key)) && !reason)return res.status(400).json({error:'A reason is required to change this sensitive record.'});
  const stamp=now();
  db.prepare('UPDATE records SET title=?,status=?,owner_user_id=?,project_id=?,due_at=?,data_json=?,updated_by=?,updated_at=? WHERE id=?')
    .run(title,status,ownerId,projectId,due,JSON.stringify(data),req.user.id,stamp,old.id);
  const after={title,status,owner_user_id:ownerId,project_id:projectId,due_at:due,sensitivity:old.sensitivity,data};
  audit(req.user.id,'record_updated',mod.key,old.id,'success',reason,{before:{title:old.title,status:old.status,owner_user_id:old.owner_user_id,project_id:old.project_id,due_at:old.due_at},after});
  addRecordHistory(old.id,mod.key,req.user.id,'updated',{title:old.title,status:old.status,owner_user_id:old.owner_user_id,project_id:old.project_id,due_at:old.due_at,data:JSON.parse(old.data_json||'{}')},after,reason);
  if(ownerId!==old.owner_user_id)notifyUser(ownerId,'info','Item reassigned to you',title,mod.key,old.id);
  res.json({record:cleanRecord(db.prepare('SELECT * FROM records WHERE id=?').get(old.id))});
});
app.post('/api/records/:module/:id/archive',requireAuth,(req,res)=>{
  const mod=modules.find(m=>m.key===req.params.module); if(!mod)return res.status(404).json({error:'Unknown module'});
  if(!['founder','super_admin'].includes(req.user.role))return res.status(403).json({error:'Only Founder or Super Admin may archive records.'});
  const old=db.prepare('SELECT * FROM records WHERE id=? AND module=? AND archived_at IS NULL').get(req.params.id,mod.key);
  if(!old)return res.status(404).json({error:'Record not found'});
  if(!String(req.body.reason||'').trim())return res.status(400).json({error:'Reason is required.'});
  db.prepare('UPDATE records SET archived_at=?,updated_by=?,updated_at=? WHERE id=?').run(now(),req.user.id,now(),old.id);
  audit(req.user.id,'record_archived',mod.key,old.id,'success',String(req.body.reason).slice(0,500));
  addRecordHistory(old.id,mod.key,req.user.id,'archived',{archived_at:null},{archived_at:now()},String(req.body.reason).slice(0,500));
  res.json({ok:true,message:'Archived, not permanently deleted.'});
});
function notifyLeadsAndFounder(actor,moduleKey,recordId,title){
  const recipients=db.prepare("SELECT id FROM users WHERE status='active' AND role IN ('founder','super_admin')").all();
  const leadRows=db.prepare("SELECT id,assigned_project_id FROM users WHERE status='active' AND role='project_lead'").all();
  for(const l of leadRows) if(!actor.assigned_project_id || l.assigned_project_id===actor.assigned_project_id) recipients.push(l);
  const insert=db.prepare('INSERT INTO notifications(id,recipient_user_id,severity,title,message,entity_type,entity_id,created_at) VALUES(?,?,?,?,?,?,?,?)');
  for(const recipient of new Set(recipients.map(r=>r.id))) insert.run(id(),recipient,'warning',`New ${moduleKey} item`,title,moduleKey,recordId,now());
}

// Member data is protected: there is intentionally no DELETE endpoint for members or their history.
app.get('/api/directory',requireAuth,(req,res)=>{
  const rows=db.prepare("SELECT id,full_name,employee_id,designation,department,work_contact FROM users WHERE status='active' ORDER BY department,full_name LIMIT 2000").all();
  audit(req.user.id,'directory_viewed','org_directory',null,'success','',{count:rows.length});res.json({members:rows});
});

app.get('/api/members',requireAuth,(req,res)=>{
  const permitted=['founder','super_admin','admin','hr'].includes(req.user.role);
  if(!permitted)return res.status(403).json({error:'Member directory permission denied'});
  const rows=db.prepare("SELECT id,email,full_name,employee_id,designation,department,role,status,assigned_project_id,work_contact,photo_path,created_at,updated_at,last_login_at,deactivated_at FROM users ORDER BY created_at DESC LIMIT 1000").all();
  audit(req.user.id,'member_directory_viewed','member',null,'success','',{count:rows.length}); res.json({members:rows});
});
app.post('/api/members',requireAuth,requireRoles('founder','super_admin','admin','hr'),async(req,res)=>{
  const b=req.body||{}; const email=String(b.email||'').trim().toLowerCase(); const name=String(b.full_name||'').trim(); const password=String(b.temporaryPassword||'');
  const allowedRoles=['admin','hr','project_lead','employee','security_reviewer','super_admin'];
  const requestedRole=String(b.role||'employee'); const role=allowedRoles.includes(requestedRole)?requestedRole:'employee';
  if(req.user.role!=='founder' && !['employee','project_lead'].includes(role))return res.status(403).json({error:'Only the Founder may create privileged roles. Admin/HR may onboard employees or project leads only.'});
  if(role==='super_admin' && req.user.role!=='founder')return res.status(403).json({error:'Only Founder may create a Super Admin.'});
  if(!/^\S+@\S+\.\S+$/.test(email)||!name||password.length<16)return res.status(400).json({error:'Valid email, full name and temporary password of at least 16 characters are required.'});
  if(req.user.role==='hr' && !['employee','project_lead'].includes(role))return res.status(403).json({error:'HR cannot create privileged accounts.'});
  if(b.assigned_project_id && !db.prepare("SELECT id FROM records WHERE id=? AND module='projects' AND archived_at IS NULL").get(String(b.assigned_project_id)))return res.status(400).json({error:'Assigned project must be an existing project record ID.'});
  try{
    const uid=id(),stamp=now(),hash=await bcrypt.hash(password,12);
    db.prepare(`INSERT INTO users(id,email,password_hash,full_name,employee_id,designation,department,role,status,assigned_project_id,work_contact,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(uid,email,hash,name,String(b.employee_id||`UH-${crypto.randomBytes(4).toString('hex').toUpperCase()}`),String(b.designation||''),String(b.department||''),role,'pending',b.assigned_project_id||null,String(b.work_contact||''),stamp,stamp);
    audit(req.user.id,'member_created','member',uid,'success','',{role}); res.status(201).json({member:db.prepare('SELECT id,email,full_name,employee_id,designation,department,role,status,created_at FROM users WHERE id=?').get(uid),message:'Member created as pending; an authorised administrator must approve activation.'});
  }catch(e){ if(String(e.message).includes('UNIQUE'))return res.status(409).json({error:'Email or employee ID already exists.'}); throw e; }
});
app.patch('/api/members/:id',requireAuth,requireRoles('founder','super_admin','admin','hr'),(req,res)=>{
  const target=db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id); if(!target)return res.status(404).json({error:'Member not found'});
  const b=req.body||{}; const changes={}; const permittedFields=['full_name','designation','department','work_contact','assigned_project_id'];
  const targetPrivileged=['founder','super_admin'].includes(target.role);
  if(targetPrivileged && req.user.role!=='founder')return res.status(403).json({error:'Only the Founder can modify a Founder/Super Admin account.'});
  if(req.user.role==='hr' && ['founder','super_admin','admin','security_reviewer'].includes(target.role))return res.status(403).json({error:'HR cannot modify privileged accounts.'});
  if(['founder','super_admin'].includes(req.user.role))permittedFields.push('role','status','employee_id');
  else if(req.user.role==='admin')permittedFields.push('status','employee_id');
  if(req.user.id===target.id && (b.role!==undefined || b.status!==undefined))return res.status(400).json({error:'You cannot change your own role or access status.'});
  for(const field of permittedFields)if(b[field]!==undefined)changes[field]=String(b[field]).slice(0,500);
  if(changes.assigned_project_id && !db.prepare("SELECT id FROM records WHERE id=? AND module='projects' AND archived_at IS NULL").get(changes.assigned_project_id))return res.status(400).json({error:'Assigned project must be an existing, non-archived project record ID.'});
  if(changes.role && !Object.hasOwn(roleLabels,changes.role))return res.status(400).json({error:'Invalid role'});
  if(changes.role && req.user.role!=='founder')return res.status(403).json({error:'Only Founder can change member roles.'});
  if(changes.role==='founder' && target.role!=='founder')return res.status(403).json({error:'A second Founder account cannot be created through role assignment.'});
  if(changes.role && !String(b.reason||'').trim())return res.status(400).json({error:'A reason is required for role changes.'});
  if(changes.role && req.user.role!=='founder' && !['employee','project_lead'].includes(changes.role))return res.status(403).json({error:'Only Founder can assign privileged roles.'});
  if(changes.status && !['pending','active','suspended','exited'].includes(changes.status))return res.status(400).json({error:'Invalid status'});
  if(changes.status && !String(b.reason||'').trim())return res.status(400).json({error:'A reason is required to change access status.'});
  if(!Object.keys(changes).length)return res.status(400).json({error:'No permitted changes supplied'});
  if(target.role==='founder' && (changes.status && changes.status!=='active' || changes.role && changes.role!=='founder'))return res.status(403).json({error:'Founder account status and role cannot be changed through this workflow.'});
  if(target.role==='super_admin' && req.user.role!=='founder')return res.status(403).json({error:'Only Founder can alter a Super Admin account.'});
  const before={};for(const k of Object.keys(changes))before[k]=target[k];
  const params={...changes,updated_at:now(),id:target.id};
  if(changes.status && ['suspended','exited'].includes(changes.status))params.deactivated_at=now();
  if(changes.status==='active')params.deactivated_at=null;
  const sets=Object.keys(changes).map(k=>`${k}=@${k}`).concat(changes.status?['deactivated_at=@deactivated_at']:[]).join(',');
  db.prepare(`UPDATE users SET ${sets},updated_at=@updated_at WHERE id=@id`).run(params);
  audit(req.user.id,'member_updated','member',target.id,'success',String(b.reason||'').slice(0,500),{before,after:changes});
  if(changes.status && ['suspended','exited'].includes(changes.status))securityEvent('warning','member_access_revoked',req.user.id,`Access status changed for member ${target.employee_id||target.id} to ${changes.status}`);
  res.json({member:db.prepare('SELECT id,email,full_name,employee_id,designation,department,role,status,assigned_project_id,work_contact,created_at,updated_at,last_login_at,deactivated_at FROM users WHERE id=?').get(target.id)});
});
app.post('/api/members/:id/approve',requireAuth,requireRoles('founder','super_admin','admin'),(req,res)=>{
  const reason=String(req.body.reason||'').trim();if(!reason)return res.status(400).json({error:'Approval reason is required.'});
  const target=db.prepare('SELECT id,status,role FROM users WHERE id=?').get(req.params.id);if(!target)return res.status(404).json({error:'Member not found'});if(target.status!=='pending')return res.status(409).json({error:'Only pending members can be approved.'});
  db.prepare("UPDATE users SET status='active',deactivated_at=NULL,updated_at=? WHERE id=?").run(now(),target.id);audit(req.user.id,'member_approved','member',target.id,'success',reason.slice(0,500),{role:target.role});addRecordHistory(target.id,'member',req.user.id,'approved', {status:'pending'},{status:'active'},reason);notifyUser(target.id,'info','Account activated','Your UpgradeHub portal account has been activated.','member',target.id);res.json({ok:true,message:'Member activated. Email verification still depends on a configured provider.'});
});

// Record discussion and history are separate from main record fields; comments can be hidden with a reason, never hard-deleted.
app.get('/api/records/:module/:id/history',requireAuth,(req,res)=>{
  const mod=modules.find(m=>m.key===req.params.module);if(!mod||!canReadModule(req.user,mod.key))return res.status(403).json({error:'Permission denied'});
  const rec=db.prepare('SELECT * FROM records WHERE id=? AND module=?').get(req.params.id,mod.key);if(!rec||!visibleRecord(req.user,rec))return res.status(404).json({error:'Record not found'});
  const history=db.prepare('SELECT id,record_id,module,actor_user_id,action,before_json,after_json,reason,created_at FROM record_history WHERE record_id=? ORDER BY created_at DESC LIMIT 100').all(rec.id).map(h=>({...h,before:h.before_json?JSON.parse(h.before_json):null,after:h.after_json?JSON.parse(h.after_json):null,before_json:undefined,after_json:undefined}));
  res.json({history});
});
app.get('/api/records/:module/:id/comments',requireAuth,(req,res)=>{
  const mod=modules.find(m=>m.key===req.params.module);if(!mod||!canReadModule(req.user,mod.key))return res.status(403).json({error:'Permission denied'});
  const rec=db.prepare('SELECT * FROM records WHERE id=? AND module=?').get(req.params.id,mod.key);if(!rec||!visibleRecord(req.user,rec))return res.status(404).json({error:'Record not found'});
  const comments=db.prepare('SELECT c.id,c.record_id,c.module,c.author_user_id,c.body,c.visibility,c.created_at,c.hidden_at,c.hidden_by,c.hidden_reason,u.full_name AS author_name FROM record_comments c LEFT JOIN users u ON u.id=c.author_user_id WHERE c.record_id=? ORDER BY c.created_at ASC LIMIT 300').all(rec.id).filter(c=>(!c.hidden_at||['founder','super_admin','admin'].includes(req.user.role))&&(!['confidential','restricted'].includes(c.visibility)||['founder','super_admin','admin','hr'].includes(req.user.role)||c.author_user_id===req.user.id));
  res.json({comments});
});
app.post('/api/records/:module/:id/comments',requireAuth,(req,res)=>{
  const mod=modules.find(m=>m.key===req.params.module);if(!mod||!canReadModule(req.user,mod.key))return res.status(403).json({error:'Permission denied'});
  const rec=db.prepare('SELECT * FROM records WHERE id=? AND module=? AND archived_at IS NULL').get(req.params.id,mod.key);if(!rec||!visibleRecord(req.user,rec))return res.status(404).json({error:'Record not found'});
  const body=String(req.body.body||'').trim();if(!body||body.length>4000)return res.status(400).json({error:'Comment must be 1–4000 characters.'});
  db.prepare('INSERT INTO record_comments(id,record_id,module,author_user_id,body,visibility,created_at) VALUES(?,?,?,?,?,?,?)').run(id(),rec.id,mod.key,req.user.id,body,['internal','confidential'].includes(req.body.visibility)?req.body.visibility:'normal',now());
  audit(req.user.id,'comment_added',mod.key,rec.id,'success','',{length:body.length});res.status(201).json({ok:true});
});
app.post('/api/records/:module/:id/comments/:commentId/hide',requireAuth,requireRoles('founder','super_admin','admin'),(req,res)=>{
  const reason=String(req.body.reason||'').trim();if(!reason)return res.status(400).json({error:'Reason is required.'});
  const mod=modules.find(m=>m.key===req.params.module);if(!mod||!canReadModule(req.user,mod.key))return res.status(403).json({error:'Permission denied'});const rec=db.prepare('SELECT * FROM records WHERE id=? AND module=?').get(req.params.id,mod.key);if(!rec||!visibleRecord(req.user,rec))return res.status(404).json({error:'Record not found'});
  const c=db.prepare('SELECT * FROM record_comments WHERE id=? AND module=? AND record_id=?').get(req.params.commentId,req.params.module,req.params.id);if(!c)return res.status(404).json({error:'Comment not found'});
  db.prepare('UPDATE record_comments SET hidden_at=?,hidden_by=?,hidden_reason=? WHERE id=?').run(now(),req.user.id,reason.slice(0,500),c.id);audit(req.user.id,'comment_hidden',c.module,c.record_id,'success',reason.slice(0,500),{commentId:c.id});res.json({ok:true,message:'Comment hidden; retained for audit.'});
});
app.post('/api/records/:module/:id/acknowledge',requireAuth,(req,res)=>{
  const mod=modules.find(m=>m.key===req.params.module);if(!mod||!canReadModule(req.user,mod.key))return res.status(403).json({error:'Permission denied'});
  const rec=db.prepare('SELECT * FROM records WHERE id=? AND module=?').get(req.params.id,mod.key);if(!rec||!visibleRecord(req.user,rec))return res.status(404).json({error:'Record not found'});
  const version=String(req.body.version||rec.updated_at).slice(0,60);try{db.prepare('INSERT INTO record_acknowledgements(id,record_id,module,user_id,version,acknowledged_at) VALUES(?,?,?,?,?,?)').run(id(),rec.id,mod.key,req.user.id,version,now());}catch(e){if(String(e.message).includes('UNIQUE'))return res.json({ok:true,alreadyAcknowledged:true});throw e;}
  audit(req.user.id,'record_acknowledged',mod.key,rec.id,'success','',{version});res.json({ok:true});
});
app.get('/api/approvals',requireAuth,(req,res)=>{
  if(!['founder','super_admin','admin','security_reviewer'].includes(req.user.role))return res.status(403).json({error:'Approval queue access denied'});
  const rows=db.prepare("SELECT * FROM approval_requests ORDER BY created_at DESC LIMIT 500").all().filter(r=>['founder','super_admin','admin'].includes(req.user.role)||r.request_type==='security_review'||r.request_type==='access_review'||r.request_type==='restore_review');res.json({approvals:rows});
});
app.post('/api/approvals',requireAuth,(req,res)=>{
  const b=req.body||{}, entityType=String(b.entity_type||'record'),entityId=String(b.entity_id||''),requestType=String(b.request_type||'approval'),reason=String(b.reason||'').trim();
  if(!entityId||!reason||reason.length>1000)return res.status(400).json({error:'Entity ID and a clear reason are required.'});
  if(!['approval','role_change','access_review','restore_review','export_review','security_review','finance_approval','contract_approval','offboarding_approval'].includes(requestType))return res.status(400).json({error:'Unsupported request type.'});
  if(entityType==='record'){const rec=db.prepare('SELECT * FROM records WHERE id=?').get(entityId);if(!rec||!canReadModule(req.user,rec.module)||!visibleRecord(req.user,rec))return res.status(404).json({error:'Record not found'});}
  const aid=id(),stamp=now();db.prepare('INSERT INTO approval_requests(id,entity_type,entity_id,requested_by,request_type,reason,status,created_at,updated_at) VALUES(?,?,?,?,?,?,\'pending\',?,?)').run(aid,entityType,entityId,req.user.id,requestType,reason,stamp,stamp);audit(req.user.id,'approval_requested',entityType,entityId,'success',reason,{approvalId:aid,requestType});notifyLeadsAndFounder(req.user,'approval',aid,`Approval requested: ${requestType}`);res.status(201).json({approval:db.prepare('SELECT * FROM approval_requests WHERE id=?').get(aid)});
});
app.post('/api/approvals/:id/decide',requireAuth,requireRoles('founder','super_admin','admin','security_reviewer'),(req,res)=>{
  const row=db.prepare('SELECT * FROM approval_requests WHERE id=?').get(req.params.id);if(!row)return res.status(404).json({error:'Approval request not found'});if(row.status!=='pending'&&row.status!=='awaiting_second_approval')return res.status(400).json({error:'This request is already finalised.'});
  if(row.requested_by===req.user.id)return res.status(403).json({error:'The requester cannot approve their own request.'});
  const doubleApprovalTypes=['role_change','access_review','restore_review','export_review','finance_approval','contract_approval','offboarding_approval'];
  const founderOnlyApprovalTypes=['role_change','restore_review','export_review'];
  if(founderOnlyApprovalTypes.includes(row.request_type)&&!['founder','super_admin'].includes(req.user.role))return res.status(403).json({error:'This high-risk request is limited to Founder/Super Admin approvers.'});
  if(req.user.role==='security_reviewer'&&!['security_review','access_review','restore_review'].includes(row.request_type))return res.status(403).json({error:'Security Reviewer cannot approve this request type.'});
  if(row.status==='awaiting_second_approval' && row.approver_1===req.user.id)return res.status(403).json({error:'Second approval must come from a different authorised person.'});
  const decision=String(req.body.decision||'');const note=String(req.body.note||'').trim();if(!['approve','reject'].includes(decision)||!note)return res.status(400).json({error:'Choose approve/reject and provide a decision note.'});
  const needsTwo=doubleApprovalTypes.includes(row.request_type);
  let status=decision==='reject'?'rejected':'approved',a1=row.approver_1,a2=row.approver_2;
  if(decision==='approve'&&needsTwo&&!a1){a1=req.user.id;status='awaiting_second_approval';}
  else if(decision==='approve'&&needsTwo&&a1&&a1!==req.user.id){a2=req.user.id;status='approved';}
  else if(decision==='approve'&&needsTwo&&a1===req.user.id)return res.status(403).json({error:'Second approval must come from a different person.'});
  db.prepare('UPDATE approval_requests SET status=?,approver_1=?,approver_2=?,decision_note=?,updated_at=? WHERE id=?').run(status,a1,a2,note,now(),row.id);audit(req.user.id,'approval_decided',row.entity_type,row.entity_id,'success',note,{approvalId:row.id,decision,status});res.json({ok:true,status,message:status==='awaiting_second_approval'?'First approval recorded; a second authorised approver is required.':'Decision recorded. Approval does not automatically execute the requested action.'});
});
app.get('/api/records/assets/:id/movements',requireAuth,(req,res)=>{
  const mod=modules.find(m=>m.key==='assets');if(!canReadModule(req.user,'assets'))return res.status(403).json({error:'Permission denied'});const rec=db.prepare("SELECT * FROM records WHERE id=? AND module='assets'").get(req.params.id);if(!rec||!visibleRecord(req.user,rec))return res.status(404).json({error:'Asset not found'});const rows=db.prepare('SELECT * FROM asset_movements WHERE asset_record_id=? ORDER BY created_at DESC LIMIT 300').all(rec.id);res.json({movements:rows});
});
app.post('/api/records/assets/:id/movements',requireAuth,(req,res)=>{
  if(!canWriteModule(req.user,'assets'))return res.status(403).json({error:'Asset movement permission denied.'});const rec=db.prepare("SELECT * FROM records WHERE id=? AND module='assets' AND archived_at IS NULL").get(req.params.id);if(!rec||!visibleRecord(req.user,rec))return res.status(404).json({error:'Asset not found'});const b=req.body||{},movement=String(b.movement_type||''),reason=String(b.reason||'').trim(),qty=Number(b.quantity||1);if(!['issue','return','repair','retire','lost','stock_adjustment','transfer'].includes(movement)||!reason||!Number.isFinite(qty)||qty<=0)return res.status(400).json({error:'Valid movement type, positive quantity and reason are required.'});if(['retire','lost','stock_adjustment'].includes(movement)&&!['founder','super_admin','admin'].includes(req.user.role))return res.status(403).json({error:'This movement requires an administrator.'});const data=JSON.parse(rec.data_json||'{}');const from=b.from_member_id||data.assigned_to||null,to=['issue','transfer'].includes(movement)?String(b.to_member_id||'').trim():(movement==='return'?null:data.assigned_to||null);if(['issue','transfer'].includes(movement)&&!to)return res.status(400).json({error:'Destination member ID is required.'});if(to&&!db.prepare('SELECT id FROM users WHERE (id=? OR employee_id=?) AND status=\'active\'').get(to,to))return res.status(400).json({error:'Destination must be an active member ID or employee ID.'});const quantityAfter=movement==='return'?Math.max(0,Number(data.quantity||1)):movement==='retire'||movement==='lost'?0:Number(data.quantity||1);if(movement==='issue'||movement==='transfer')data.assigned_to=to;if(movement==='return')data.assigned_to='';if(movement==='repair')data.condition='repair';if(movement==='retire')data.condition='retired';if(movement==='lost')data.condition='lost';db.prepare('UPDATE records SET data_json=?,updated_by=?,updated_at=? WHERE id=?').run(JSON.stringify(data),req.user.id,now(),rec.id);const mid=id();db.prepare('INSERT INTO asset_movements(id,asset_record_id,movement_type,from_member_id,to_member_id,quantity,reason,approved_by,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)').run(mid,rec.id,movement,from,to,qty,reason,req.user.id,req.user.id,now());audit(req.user.id,'asset_movement', 'assets',rec.id,'success',reason,{movement,from,to,quantity:qty,quantityAfter});addRecordHistory(rec.id,'assets',req.user.id,'asset_movement',{data:JSON.parse(rec.data_json||'{}')},{data},reason);if(to){const uid=db.prepare('SELECT id FROM users WHERE id=? OR employee_id=?').get(to,to)?.id;notifyUser(uid,'info','Asset assigned',rec.title,'assets',rec.id);}res.status(201).json({movement:db.prepare('SELECT * FROM asset_movements WHERE id=?').get(mid)});
});

app.get('/api/operations/status',requireAuth,requireRoles('founder','super_admin','admin'),(req,res)=>{
  const lastRun=db.prepare('SELECT job_name,status,details_json,started_at,finished_at FROM job_runs ORDER BY started_at DESC LIMIT 20').all().map(x=>({...x,details:JSON.parse(x.details_json||'{}'),details_json:undefined}));
  const files=db.prepare('SELECT COUNT(*) AS n FROM private_files WHERE quarantined=0').get().n;
  res.json({moduleCount:modules.length,openApprovals:db.prepare("SELECT COUNT(*) AS n FROM approval_requests WHERE status IN ('pending','awaiting_second_approval')").get().n,privateFileCount:files,recentJobRuns:lastRun});
});
function listEncryptedBackups(){
  const dir=path.resolve(process.env.BACKUP_DIR||'./backups');
  if(!fs.existsSync(dir))return [];
  return fs.readdirSync(dir,{withFileTypes:true}).filter(e=>e.isFile()&&/^upgradehub-[A-Za-z0-9T_.-]+\.uhbak$/.test(e.name)).map(e=>{const full=path.join(dir,e.name),st=fs.statSync(full);return {name:e.name,size_bytes:st.size,modified_at:st.mtime.toISOString()};}).sort((a,b)=>b.modified_at.localeCompare(a.modified_at));
}
app.get('/api/operations/backups',requireAuth,requireRoles('founder','super_admin'),(req,res)=>res.json({backups:listEncryptedBackups(),directoryConfigured:path.resolve(process.env.BACKUP_DIR||'./backups')}));
app.post('/api/operations/backups/run',requireAuth,requireRoles('founder','super_admin'),async(req,res)=>{
  const reason=String(req.body.reason||'').trim();if(reason.length<8)return res.status(400).json({error:'A reason of at least 8 characters is required to create a backup.'});
  const jobId=id(),started=now();db.prepare('INSERT INTO job_runs(id,job_name,status,details_json,started_at) VALUES(?,?,?,?,?)').run(jobId,'encrypted_full_backup','running',JSON.stringify({requestedBy:req.user.id}),started);
  try{
    const script=path.join(__dirname,'..','scripts','backup-db.js');
    const result=await execFileAsync(process.execPath,[script],{cwd:path.resolve('.'),env:process.env,timeout:300000,maxBuffer:1024*1024});
    const detail={stdout:String(result.stdout||'').slice(-4000),stderr:String(result.stderr||'').slice(-2000),backupCount:listEncryptedBackups().length};
    db.prepare('UPDATE job_runs SET status=?,details_json=?,finished_at=? WHERE id=?').run('completed',JSON.stringify(detail),now(),jobId);
    audit(req.user.id,'encrypted_backup_created','backup',jobId,'success',reason.slice(0,500),{backupCount:detail.backupCount});
    res.status(201).json({ok:true,jobId,message:'Encrypted backup created. Copy it to an isolated destination and test restoration separately.',backups:listEncryptedBackups()});
  }catch(error){
    db.prepare('UPDATE job_runs SET status=?,details_json=?,finished_at=? WHERE id=?').run('failed',JSON.stringify({error:String(error.message||'backup failed').slice(0,1000)}),now(),jobId);
    audit(req.user.id,'encrypted_backup_failed','backup',jobId,'failed',reason.slice(0,500),{});securityEvent('warning','encrypted_backup_failed',req.user.id,'Encrypted backup job failed. Check authorised server-side logs; secret values are not returned.');
    res.status(500).json({error:'Encrypted backup failed. Check the backup key and authorised server logs.'});
  }
});
app.get('/api/operations/backups/:filename/download',requireAuth,requireRoles('founder','super_admin'),(req,res)=>{
  const filename=String(req.params.filename||'');const reason=String(req.query.reason||'').trim();
  if(path.basename(filename)!==filename||!/^upgradehub-[A-Za-z0-9T_.-]+\.uhbak$/.test(filename))return res.status(400).json({error:'Invalid backup filename.'});
  if(reason.length<8)return res.status(400).json({error:'A reason of at least 8 characters is required for backup download.'});
  const full=path.join(path.resolve(process.env.BACKUP_DIR||'./backups'),filename);if(!fs.existsSync(full)||!fs.statSync(full).isFile())return res.status(404).json({error:'Backup not found.'});
  audit(req.user.id,'encrypted_backup_downloaded','backup',filename,'success',reason.slice(0,500),{sizeBytes:fs.statSync(full).size});
  res.setHeader('Content-Type','application/octet-stream');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Content-Disposition',`attachment; filename=\"${filename}\"`);res.sendFile(full);
});
function canAccessPrivateFile(user,file,record){
  if(['founder','super_admin'].includes(user.role))return true;
  if(file.owner_user_id===user.id)return true;
  if(!record||!canReadModule(user,file.module)||!visibleRecord(user,record))return false;
  if(file.classification==='internal')return true;
  if(file.classification==='confidential')return ['admin','hr','project_lead'].includes(user.role);
  if(file.classification==='restricted')return user.role==='hr'&&['grievances','hr_cases','document_vault'].includes(file.module);
  return false;
}
const uploadSingle=upload.single('file');
app.post('/api/files/upload',requireAuth,(req,res)=>uploadSingle(req,res,err=>{
  if(err)return res.status(400).json({error:err.message||'Upload failed.'});
  if(!req.file)return res.status(400).json({error:'Choose a file to upload.'});
  const mod=modules.find(m=>m.key===String(req.body.module||''));const recordId=String(req.body.record_id||'');
  if(!mod||!recordId||!canWriteModule(req.user,mod.key)){return res.status(403).json({error:'An authorised module and editable record are required for private uploads.'});}
  const rec=db.prepare('SELECT * FROM records WHERE id=? AND module=? AND archived_at IS NULL').get(recordId,mod.key);if(!rec||!visibleRecord(req.user,rec))return res.status(404).json({error:'Record not found or permission denied.'});
  const buf=req.file.buffer,ext=path.extname(req.file.originalname||'').toLowerCase();
  const signatures={'.pdf':buf.subarray(0,5).toString()==='%PDF-','.png':buf.subarray(0,4).equals(Buffer.from([137,80,78,71])),'.jpg':buf[0]===255&&buf[1]===216&&buf[2]===255,'.jpeg':buf[0]===255&&buf[1]===216&&buf[2]===255,'.docx':buf[0]===80&&buf[1]===75,'.xlsx':buf[0]===80&&buf[1]===75,'.txt':!buf.includes(0),'.csv':!buf.includes(0)};
  if(!signatures[ext]){securityEvent('warning','file_signature_rejected',req.user.id,`A private upload failed file-signature validation for ${ext}`);return res.status(400).json({error:'File contents do not match the selected document type.'});}
  const storedName=`${crypto.randomUUID()}${ext}`;const full=path.join(PRIVATE_UPLOAD_DIR,storedName);fs.writeFileSync(full,buf,{flag:'wx',mode:0o600});const sha=crypto.createHash('sha256').update(buf).digest('hex');const fid=id();
  const classification=['grievances','hr_cases','document_vault'].includes(mod.key)?'restricted':(['confidential','restricted'].includes(req.body.classification)?req.body.classification:'internal');
  db.prepare('INSERT INTO private_files(id,original_name,stored_name,mime_type,byte_size,sha256,module,record_id,owner_user_id,classification,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)').run(fid,path.basename(req.file.originalname).slice(0,240),storedName,req.file.mimetype||'application/octet-stream',buf.length,sha,mod.key,rec.id,req.user.id,classification,now());audit(req.user.id,'private_file_uploaded',mod.key,rec.id,'success','',{fileId:fid,sha256:sha,size:buf.length,classification});res.status(201).json({file:{id:fid,original_name:path.basename(req.file.originalname),byte_size:buf.length,sha256:sha,classification,created_at:now()},message:'Uploaded to private storage; malware scanning is not configured in this build.'});
}));
app.get('/api/files',requireAuth,(req,res)=>{
  const moduleKey=String(req.query.module||''),recordId=String(req.query.record_id||'');if(!moduleKey||!recordId)return res.status(400).json({error:'module and record_id are required.'});const mod=modules.find(m=>m.key===moduleKey);if(!mod||!canReadModule(req.user,mod.key))return res.status(403).json({error:'Permission denied'});const rec=db.prepare('SELECT * FROM records WHERE id=? AND module=?').get(recordId,moduleKey);if(!rec||!visibleRecord(req.user,rec))return res.status(404).json({error:'Record not found'});const files=db.prepare('SELECT id,original_name,mime_type,byte_size,sha256,module,record_id,owner_user_id,classification,created_at FROM private_files WHERE module=? AND record_id=? AND quarantined=0 ORDER BY created_at DESC').all(moduleKey,recordId).filter(f=>canAccessPrivateFile(req.user,f,rec));res.json({files});
});
app.get('/api/files/:id/download',requireAuth,(req,res)=>{
  const f=db.prepare('SELECT * FROM private_files WHERE id=? AND quarantined=0').get(req.params.id);if(!f)return res.status(404).json({error:'File not found'});if(!f.module||!f.record_id){if(f.owner_user_id!==req.user.id&&!['founder','super_admin'].includes(req.user.role))return res.status(403).json({error:'Permission denied'});}else{const rec=db.prepare('SELECT * FROM records WHERE id=? AND module=?').get(f.record_id,f.module);if(!canAccessPrivateFile(req.user,f,rec))return res.status(403).json({error:'Private file access denied'});}
  const full=path.join(PRIVATE_UPLOAD_DIR,f.stored_name);if(!fs.existsSync(full))return res.status(404).json({error:'Stored file is unavailable'});audit(req.user.id,'private_file_downloaded',f.module||'file',f.record_id||f.id,'success','',{fileId:f.id,sha256:f.sha256});res.setHeader('Content-Type','application/octet-stream');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Content-Disposition',`attachment; filename="${String(f.original_name).replace(/["\r\n]/g,'_')}"`);res.sendFile(full);
});
app.post('/api/operations/run-jobs',requireAuth,requireRoles('founder','super_admin'),(req,res)=>{
  try { res.json(runOperationalReminderJob(req.user.id,'manual')); } catch(error) { res.status(500).json({error:'Operational job failed; a security event was logged.'}); }
});

app.get('/api/notifications',requireAuth,(req,res)=>res.json({notifications:db.prepare('SELECT * FROM notifications WHERE recipient_user_id=? ORDER BY created_at DESC LIMIT 100').all(req.user.id)}));
app.post('/api/notifications/:id/read',requireAuth,(req,res)=>{const r=db.prepare('UPDATE notifications SET read_at=? WHERE id=? AND recipient_user_id=?').run(now(),req.params.id,req.user.id);res.json({ok:r.changes>0});});
app.get('/api/audit',requireAuth,(req,res)=>{
  if(!['founder','super_admin','security_reviewer'].includes(req.user.role))return res.status(403).json({error:'Audit log access denied'});
  const rows=db.prepare('SELECT id,actor_user_id,action,entity_type,entity_id,outcome,reason,metadata_json,created_at FROM audit_logs ORDER BY created_at DESC LIMIT 1000').all().filter(r=>req.user.role!=='security_reviewer'||['incident','security_event','permissions_access','sessions_devices','integrations','continuity','backup_jobs','data_requests','compliance','policy','user'].includes(r.entity_type)).slice(0,500).map(r=>({...r,metadata:JSON.parse(r.metadata_json||'{}'),metadata_json:undefined}));
  res.json({logs:rows});
});
app.get('/api/security/events',requireAuth,(req,res)=>{
  if(!['founder','super_admin','security_reviewer'].includes(req.user.role))return res.status(403).json({error:'Security event access denied'});
  res.json({events:db.prepare('SELECT * FROM security_events ORDER BY created_at DESC LIMIT 300').all()});
});
app.post('/api/security/events/:id/resolve',requireAuth,requireRoles('founder','super_admin','security_reviewer'),(req,res)=>{
  if(!String(req.body.reason||'').trim())return res.status(400).json({error:'Resolution reason is required.'});
  db.prepare("UPDATE security_events SET status='resolved',resolved_at=? WHERE id=?").run(now(),req.params.id);audit(req.user.id,'security_event_resolved','security_event',req.params.id,'success',String(req.body.reason).slice(0,500));res.json({ok:true});
});
app.post('/api/policies/:key/acknowledge',requireAuth,(req,res)=>{
  const key=String(req.params.key).slice(0,100),version=String(req.body.version||'1.0').slice(0,30);
  db.prepare('INSERT INTO policy_acknowledgements(id,user_id,policy_key,policy_version,acknowledged_at) VALUES(?,?,?,?,?)').run(id(),req.user.id,key,version,now());audit(req.user.id,'policy_acknowledged','policy',key);res.json({ok:true});
});
app.get('/api/policies/acknowledgements',requireAuth,requireRoles('founder','super_admin','hr'),(req,res)=>res.json({acknowledgements:db.prepare('SELECT id,user_id,policy_key,policy_version,acknowledged_at FROM policy_acknowledgements ORDER BY acknowledged_at DESC LIMIT 1000').all()}));

app.get('/api/export/records/:module',requireAuth,(req,res)=>{
  if(!['founder','super_admin'].includes(req.user.role))return res.status(403).json({error:'Only Founder or Super Admin may export module records.'});
  const mod=modules.find(m=>m.key===req.params.module);if(!mod)return res.status(404).json({error:'Unknown module'});
  if(!String(req.query.reason||'').trim())return res.status(400).json({error:'Export reason is required.'});
  const rows=db.prepare('SELECT * FROM records WHERE module=? AND archived_at IS NULL ORDER BY created_at').all(mod.key).map(cleanRecord);
  audit(req.user.id,'records_exported',mod.key,null,'success',String(req.query.reason).slice(0,500),{count:rows.length});
  res.setHeader('Content-Disposition',`attachment; filename="upgradehub-${mod.key}-export.json"`);res.json({exported_at:now(),module:mod.key,records:rows});
});

// Local in-process scheduler: runs in-app reminders hourly. Email/push delivery still requires a provider.
const reminderTimer=setInterval(()=>{try{runOperationalReminderJob('system','scheduled');}catch(error){console.error('Scheduled reminder job failed:',error.message);}},60*60*1000);
reminderTimer.unref();
setTimeout(()=>{try{runOperationalReminderJob('system','startup');}catch(error){console.error('Startup reminder job failed:',error.message);}},15000).unref();

app.use(express.static(path.join(__dirname,'..','public'),{extensions:['html'],index:'index.html',maxAge:production?'1h':0}));
app.use((err,req,res,next)=>{console.error('Request error:',err.message);if(!res.headersSent)res.status(500).json({error:'Internal server error',requestId:crypto.randomUUID()});});
app.listen(PORT,'0.0.0.0',()=>console.log(`UpgradeHub Company Portal listening on port ${PORT}`));
