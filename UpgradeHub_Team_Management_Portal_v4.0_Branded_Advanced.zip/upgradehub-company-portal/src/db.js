const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const dbPath = path.resolve(process.env.DATABASE_PATH || './data/upgradehub.sqlite');
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  employee_id TEXT UNIQUE,
  designation TEXT DEFAULT '',
  department TEXT DEFAULT '',
  role TEXT NOT NULL DEFAULT 'employee',
  status TEXT NOT NULL DEFAULT 'pending',
  assigned_project_id TEXT,
  work_contact TEXT DEFAULT '',
  photo_path TEXT DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  last_login_at TEXT,
  deactivated_at TEXT
);
CREATE TABLE IF NOT EXISTS records (
  id TEXT PRIMARY KEY,
  module TEXT NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  owner_user_id TEXT,
  project_id TEXT,
  due_at TEXT,
  sensitivity TEXT NOT NULL DEFAULT 'internal',
  data_json TEXT NOT NULL DEFAULT '{}',
  created_by TEXT NOT NULL,
  updated_by TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  archived_at TEXT,
  FOREIGN KEY(owner_user_id) REFERENCES users(id),
  FOREIGN KEY(created_by) REFERENCES users(id),
  FOREIGN KEY(updated_by) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_records_module ON records(module, archived_at, updated_at);
CREATE INDEX IF NOT EXISTS idx_records_owner ON records(owner_user_id, module);
CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  actor_user_id TEXT,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT,
  outcome TEXT NOT NULL,
  reason TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY,
  recipient_user_id TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'info',
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  entity_type TEXT,
  entity_id TEXT,
  read_at TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY(recipient_user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS policy_acknowledgements (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  policy_key TEXT NOT NULL,
  policy_version TEXT NOT NULL,
  acknowledged_at TEXT NOT NULL,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS security_events (
  id TEXT PRIMARY KEY,
  severity TEXT NOT NULL,
  event_type TEXT NOT NULL,
  actor_user_id TEXT,
  description TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT NOT NULL,
  resolved_at TEXT
);
CREATE TABLE IF NOT EXISTS record_history (
  id TEXT PRIMARY KEY, record_id TEXT NOT NULL, module TEXT NOT NULL,
  actor_user_id TEXT, action TEXT NOT NULL, before_json TEXT, after_json TEXT,
  reason TEXT, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_record_history_record ON record_history(record_id,created_at);
CREATE TABLE IF NOT EXISTS record_comments (
  id TEXT PRIMARY KEY, record_id TEXT NOT NULL, module TEXT NOT NULL,
  author_user_id TEXT NOT NULL, body TEXT NOT NULL, visibility TEXT NOT NULL DEFAULT 'normal',
  created_at TEXT NOT NULL, hidden_at TEXT, hidden_by TEXT, hidden_reason TEXT
);
CREATE INDEX IF NOT EXISTS idx_comments_record ON record_comments(record_id,created_at);
CREATE TABLE IF NOT EXISTS private_files (
  id TEXT PRIMARY KEY, original_name TEXT NOT NULL, stored_name TEXT NOT NULL,
  mime_type TEXT NOT NULL, byte_size INTEGER NOT NULL, sha256 TEXT NOT NULL,
  module TEXT, record_id TEXT, owner_user_id TEXT NOT NULL,
  classification TEXT NOT NULL DEFAULT 'internal', created_at TEXT NOT NULL,
  quarantined INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_private_files_record ON private_files(record_id, module);
CREATE TABLE IF NOT EXISTS approval_requests (
  id TEXT PRIMARY KEY, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL,
  requested_by TEXT NOT NULL, request_type TEXT NOT NULL, reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending', approver_1 TEXT, approver_2 TEXT,
  decision_note TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_approvals_status ON approval_requests(status,created_at);
CREATE TABLE IF NOT EXISTS job_runs (
  id TEXT PRIMARY KEY, job_name TEXT NOT NULL, status TEXT NOT NULL,
  details_json TEXT NOT NULL DEFAULT '{}', started_at TEXT NOT NULL, finished_at TEXT
);
CREATE TABLE IF NOT EXISTS record_acknowledgements (
  id TEXT PRIMARY KEY, record_id TEXT NOT NULL, module TEXT NOT NULL,
  user_id TEXT NOT NULL, version TEXT NOT NULL, acknowledged_at TEXT NOT NULL,
  UNIQUE(record_id,user_id,version)
);
CREATE TABLE IF NOT EXISTS asset_movements (
  id TEXT PRIMARY KEY, asset_record_id TEXT NOT NULL, movement_type TEXT NOT NULL,
  from_member_id TEXT, to_member_id TEXT, quantity REAL NOT NULL DEFAULT 1,
  reason TEXT NOT NULL, approved_by TEXT NOT NULL, created_by TEXT NOT NULL, created_at TEXT NOT NULL
);

`);
module.exports = db;
